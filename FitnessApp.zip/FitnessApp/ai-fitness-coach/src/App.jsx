// src/App.jsx
import { useState, useRef } from "react";
import ReactMarkdown from "react-markdown";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { generatePlan } from "./apiService";

function App() {
  const [form, setForm] = useState({
    name: "",
    age: "",
    gender: "",
    height: "",
    weight: "",
    goal: "weight_loss",
    level: "beginner",
    location: "home",
    diet: "veg",
  });

  const [showData, setShowData] = useState(false);
  const [aiPlan, setAiPlan] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [speaking, setSpeaking] = useState(false);

  // image generation state
  const [imagePrompt, setImagePrompt] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [imageLoading, setImageLoading] = useState(false);
  const [imageError, setImageError] = useState("");

  // For PDF capture
  const planRef = useRef(null);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setShowData(true);
    setAiPlan("");
    setErrorMsg("");
    setLoading(true);

    // stop any ongoing speech when regenerating
    stopSpeaking();

    try {
      const plan = await generatePlan(form);
      setAiPlan(plan);

      // reset image area when new plan is generated
      setImagePrompt("");
      setImageUrl("");
      setImageError("");
    } catch (err) {
      const msg = err?.message || "Something went wrong while calling AI.";
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  }

  // ---------- PDF DOWNLOAD ----------
  async function handleDownloadPdf() {
    if (!aiPlan || !planRef.current) return;

    const element = planRef.current;

    const canvas = await html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("ai-fitness-plan.pdf");
  }

  // ---------- VOICE / TTS ----------
  function stopSpeaking() {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    }
  }

  function speakText(text) {
    if (!text) return;

    if (typeof window === "undefined" || !window.speechSynthesis) {
      alert("Speech is not supported in this browser.");
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);

    // Try to select an Indian English voice
    const voices = window.speechSynthesis.getVoices();
    const indianVoice =
      voices.find((v) => v.lang === "en-IN") ||
      voices.find((v) => v.name.toLowerCase().includes("india")) ||
      voices.find((v) => v.lang === "en-GB") ||
      voices[0];

    if (indianVoice) utterance.voice = indianVoice;

    utterance.pitch = 1;
    utterance.rate = 1;

    setSpeaking(true);

    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }

  // extract workout / diet sections for TTS
  function getSectionText(section) {
    if (!aiPlan) return "";

    const lower = aiPlan.toLowerCase();
    const workoutStart = lower.indexOf("1) workout plan");
    const dietStart = lower.indexOf("2) diet plan");
    const tipsStart =
      lower.indexOf("3) tips") >= 0 ? lower.indexOf("3) tips") : aiPlan.length;

    if (section === "workout" && workoutStart !== -1) {
      const end = dietStart !== -1 ? dietStart : tipsStart;
      return aiPlan.slice(workoutStart, end);
    }

    if (section === "diet" && dietStart !== -1) {
      const end = tipsStart;
      return aiPlan.slice(dietStart, end);
    }

    return aiPlan;
  }

  function handleSpeakWorkout() {
    const text = getSectionText("workout");
    speakText(text);
  }

  function handleSpeakDiet() {
    const text = getSectionText("diet");
    speakText(text);
  }

  // ---------- IMAGE GENERATION ----------
  function generateImageFromText(rawText) {
    if (!rawText) return;

    const cleaned = String(rawText).trim();
    const prompt = `High quality illustration of ${cleaned}, fitness or food style, realistic, dark background`;

    setImagePrompt(cleaned);
    setImageError("");
    setImageLoading(true);
    setImageUrl("");

    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      prompt
    )}`;

    // simply set URL, <img> will load it
    setImageUrl(url);
    setImageLoading(false);
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center">
      <div className="max-w-3xl w-full px-4 py-8">
        {/* Header */}
        <header className="mb-6 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            💪 AI Fitness Coach
          </h1>
          <p className="text-slate-300 text-sm md:text-base">
            Enter your details to generate a personalized workout &amp; diet
            plan.
          </p>
        </header>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-slate-800/70 border border-slate-700 rounded-2xl p-6 space-y-4 shadow-lg"
        >
          {/* Name */}
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium">Name</label>
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Enter your name"
              className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Age + Gender */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Age</label>
              <input
                type="number"
                name="age"
                value={form.age}
                onChange={handleChange}
                placeholder="23"
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Gender</label>
              <select
                name="gender"
                value={form.gender}
                onChange={handleChange}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">Select gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other / Prefer not say</option>
              </select>
            </div>
          </div>

          {/* Height + Weight */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Height (cm)</label>
              <input
                type="number"
                name="height"
                value={form.height}
                onChange={handleChange}
                placeholder="e.g. 178"
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Weight (kg)</label>
              <input
                type="number"
                name="weight"
                value={form.weight}
                onChange={handleChange}
                placeholder="e.g. 75"
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Goal */}
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium">Fitness Goal</label>
            <select
              name="goal"
              value={form.goal}
              onChange={handleChange}
              className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="weight_loss">Weight Loss</option>
              <option value="muscle_gain">Muscle Gain</option>
              <option value="general_fitness">General Fitness</option>
            </select>
          </div>

          {/* Level + Location + Diet */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Fitness Level</label>
              <select
                name="level"
                value={form.level}
                onChange={handleChange}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Workout Location</label>
              <select
                name="location"
                value={form.location}
                onChange={handleChange}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="home">Home</option>
                <option value="gym">Gym</option>
                <option value="outdoor">Outdoor</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium">Diet Preference</label>
              <select
                name="diet"
                value={form.diet}
                onChange={handleChange}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="veg">Veg</option>
                <option value="non_veg">Non-Veg</option>
                <option value="vegan">Vegan</option>
                <option value="keto">Keto</option>
              </select>
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 disabled:cursor-not-allowed text-slate-900 font-semibold py-2 rounded-xl text-sm transition"
          >
            {loading ? "Generating plan..." : "Generate AI Plan"}
          </button>
        </form>

        {/* Error message */}
        {errorMsg && (
          <div className="mt-4 bg-red-900/60 border border-red-500 text-red-100 rounded-xl px-4 py-3 text-sm">
            <strong>Error: </strong> {errorMsg}
          </div>
        )}

        {/* Show entered data */}
        {showData && (
          <div className="mt-6 bg-slate-800/70 border border-slate-700 rounded-2xl p-6 text-sm">
            <h2 className="text-xl font-semibold mb-4">
              Your Entered Details
            </h2>
            <p>
              <strong>Name:</strong> {form.name}
            </p>
            <p>
              <strong>Age:</strong> {form.age}
            </p>
            <p>
              <strong>Gender:</strong> {form.gender}
            </p>
            <p>
              <strong>Height:</strong> {form.height} cm
            </p>
            <p>
              <strong>Weight:</strong> {form.weight} kg
            </p>
            <p>
              <strong>Goal:</strong> {form.goal}
            </p>
            <p>
              <strong>Level:</strong> {form.level}
            </p>
            <p>
              <strong>Workout Location:</strong> {form.location}
            </p>
            <p>
              <strong>Diet Preference:</strong> {form.diet}
            </p>
          </div>
        )}

        {/* AI Generated Plan (Markdown + PDF + Voice + Images) */}
        {aiPlan && (
          <div
            ref={planRef}
            className="mt-6 bg-slate-800/70 border border-emerald-600 rounded-2xl p-6 text-sm"
          >
            <h2 className="text-xl font-semibold mb-4 text-emerald-400">
              ✨ AI Generated Workout &amp; Diet Plan
            </h2>

            <p className="text-xs text-slate-300 mb-2">
              Tip: Click on any exercise or meal bullet to see an AI-generated
              image for that item.
            </p>

            <div className="space-y-3 leading-relaxed text-slate-100">
              <ReactMarkdown
                components={{
                  li: ({ node, children, ...props }) => {
                    const text = Array.isArray(children)
                      ? children
                          .map((child) =>
                            typeof child === "string" ? child : ""
                          )
                          .join(" ")
                      : String(children ?? "");

                    return (
                      <li
                        {...props}
                        onClick={() => generateImageFromText(text)}
                        className="cursor-pointer hover:text-emerald-300"
                      >
                        {children}
                      </li>
                    );
                  },
                }}
              >
                {aiPlan}
              </ReactMarkdown>
            </div>

            {/* Buttons row */}
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-900 font-semibold text-xs md:text-sm hover:bg-emerald-400 transition"
              >
                📄 Download Plan as PDF
              </button>

              <button
                type="button"
                onClick={handleSpeakWorkout}
                disabled={speaking}
                className="px-4 py-2 rounded-lg bg-sky-500 text-slate-900 font-semibold text-xs md:text-sm hover:bg-sky-400 disabled:opacity-60 disabled:cursor-not-allowed transition"
              >
                🔊 Read Workout
              </button>

              <button
                type="button"
                onClick={handleSpeakDiet}
                disabled={speaking}
                className="px-4 py-2 rounded-lg bg-indigo-500 text-slate-50 font-semibold text-xs md:text-sm hover:bg-indigo-400 disabled:opacity-60 disabled:cursor-not-allowed transition"
              >
                🔊 Read Diet
              </button>

              <button
                type="button"
                onClick={stopSpeaking}
                className="px-4 py-2 rounded-lg bg-red-500 text-slate-50 font-semibold text-xs md:text-sm hover:bg-red-400 transition"
              >
                ⏹ Stop Voice
              </button>
            </div>

            {/* Image preview section */}
            {imagePrompt && (
              <div className="mt-4">
                <p className="text-xs text-slate-300 mb-2">
                  Image for:{" "}
                  <span className="font-semibold">{imagePrompt}</span>
                </p>

                {imageLoading && (
                  <p className="text-xs text-slate-200">
                    Generating image…
                  </p>
                )}

                {imageError && (
                  <p className="text-xs text-red-400">{imageError}</p>
                )}

                {imageUrl && (
                  <img
                    src={imageUrl}
                    alt={imagePrompt}
                    className="w-full max-h-80 object-cover rounded-xl border border-slate-700"
                  />
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
